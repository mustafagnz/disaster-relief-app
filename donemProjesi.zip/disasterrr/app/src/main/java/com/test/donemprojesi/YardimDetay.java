package com.test.donemprojesi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class YardimDetay extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yardim_detay);
    }
}